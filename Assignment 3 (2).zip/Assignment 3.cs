using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    
    public class EmailService
    {
        public void SendConfirmationEmail(string customerEmail)
        {
            Console.WriteLine($"Email sent to {customerEmail}");
        }
    }

    public class InventoryService
    {
        public void UpdateInventory(string product, int quantity)
        {
            Console.WriteLine($"Inventory updated for {product}, quantity reduced by {quantity}");
        }
    }

    public class PaymentService
    {
        public void ChargeCustomer(string customerName, decimal amount)
        {
            Console.WriteLine($"Charged {customerName} amount: {amount}");
        }
    }

    public class OrderService
    {
        private EmailService _emailService;
        private InventoryService _inventoryService;
        private PaymentService _paymentService;

        public OrderService()
        {
            _emailService = new EmailService();
            _inventoryService = new InventoryService();
            _paymentService = new PaymentService();
        }

        public void ProcessOrder(string customerName, string customerEmail, string product, int quantity, decimal price)
        {
            _paymentService.ChargeCustomer(customerName, price * quantity);
            _inventoryService.UpdateInventory(product, quantity);
            _emailService.SendConfirmationEmail(customerEmail);

            Console.WriteLine("Order processed successfully.");
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            OrderService orderService = new OrderService();
            orderService.ProcessOrder("Alan", "alan@macewan.ca", "Laptop", 1, 999.99m);
        }
    }
}
